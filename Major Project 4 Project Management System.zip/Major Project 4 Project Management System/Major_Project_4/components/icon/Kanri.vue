<!-- SPDX-FileCopyrightText: Copyright (c) 2022-2025 trobonox <hello@trobo.dev> -->
<!-- -->
<!-- SPDX-License-Identifier: GPL-3.0-or-later -->
<!--
Kanri is an offline Kanban board app made using Tauri and Nuxt.
Copyright (C) 2022-2025 trobonox <hello@trobo.dev>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>. -->

<template>
  <svg
    width="491"
    height="482"
    viewBox="0 0 491 482"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M263.336 75H380.286C352.987 134.282 312.264 205.923 261.284 267.662C193.608 349.618 114.375 406.463 30.2685 406.463V481.463C148.528 481.463 246.943 402.82 319.115 315.417C392.233 226.87 445.125 121.417 471.813 50.7489L490.979 0H436.731H0V75H179.996C165.321 102.983 146.404 133.361 124.14 160.31C85.1362 207.523 42.4065 236.527 0 236.527V311.527C76.592 311.527 138.505 260.68 181.961 208.078C217.709 164.807 245.417 115.091 263.336 75Z"
      fill="currentColor"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M263.336 75H380.286C352.987 134.282 312.264 205.923 261.284 267.662C193.608 349.618 114.375 406.463 30.2685 406.463V481.463C148.528 481.463 246.943 402.82 319.115 315.417C392.233 226.87 445.125 121.417 471.813 50.7489L490.979 0H436.731H0V75H179.996C165.321 102.983 146.404 133.361 124.14 160.31C85.1362 207.523 42.4065 236.527 0 236.527V311.527C76.592 311.527 138.505 260.68 181.961 208.078C217.709 164.807 245.417 115.091 263.336 75Z"
      fill="url(#paint0_linear_493_48)"
      fill-opacity="0.5"
    />
    <defs>
      <linearGradient
        id="paint0_linear_493_48"
        x1="6.99997"
        y1="506.5"
        x2="837"
        y2="-385.5"
        gradientUnits="userSpaceOnUse"
      >
        <stop />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
    </defs>
  </svg>
</template>
