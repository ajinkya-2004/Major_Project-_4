export const useSettingsStore = defineStore("settings", {
  state: () => ({
    animationsEnabled: true,
  }),
});
